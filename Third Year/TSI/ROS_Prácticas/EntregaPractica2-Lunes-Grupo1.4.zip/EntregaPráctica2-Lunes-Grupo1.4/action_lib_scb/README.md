# action_lib_scb
modificación del modulo para ROS que indica a un robot un comportamiento basado en campos de potencial. Implementacion original de Juan Fernandez Olivares (faro@decsai.ugr.es)
